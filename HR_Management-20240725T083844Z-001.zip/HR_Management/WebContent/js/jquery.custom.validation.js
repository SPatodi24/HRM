
//	------------------------------------addEmployee.jsp-----------------------------------------//
var a = {

	rules : {
		mailid : {
			required : true,
			email : true
		},

		pswd : {
			required : true,
			minlength : 4
		},
		empid : "required"
	},
	messages : {
		empid : "Please enter the Employee ID.",
		pswd : {
			minlength : "Atleast 4 characters are required.",
			required : "This is a required field."
		}
	}
}

// -------------------------------------addAparDetails.jsp----------------------------------------------------------//



var b = {
	rules : {
		payroll : {
			required : true,
			
		},
		position : {
			required : true,
			
		},
		dept : "required",
		cemail : {
			required : true,
			email : true
		},
		salary : {
			required : true,
			number : true
		},
		status : "required",
		manager : "required",
		etype : "required",
		'crole[]': { 

			required: true
		}
	},
	messages : {

		'crole[]': {  required: "You must check at least 1 box" },
		
		payroll : {
			
			required : "This is a required field."
		},
		position : {
			required : "This is a required field.",
			
		},
		dept : "This is a required field.",
		cemail : {
			required : "This is a required field.",
			email : "Please enter a valid Email ID."
		},
		salary : {
			required : "This is a required field.",
			number : "Only digits allowed."
		},
		status : "This is a required field.",
		manager : "This is a required field.",
		etype : "This is a required field."

	}
}

//	-----------------------------------AddEvent.jsp-------------------------------------//
var event	=	{
		rules: {
			ename:"required",
			venue:"required",
			},
		
		messages:{
			ename:"This is a required field.",
			venue:"This is a required field."
		}	
}

//-----------------------------------addNews.jsp-------------------------------------//
var news	=	{
	rules: {
		nname:"required"
		
	},
	
	messages:{
		nname:"This is a required field."
		
	}	
}

//-----------------------------------changePassword.jsp(both)-------------------------------------//
var chpasAd	=	{
	rules: {
			oldpass:"required",
			newpass:{
				required: true,
			    minlength: 4,
			    maxlength: 15
			},
			confirmpass:{
				required: true,
				equalTo: "#newpass",
			    minlength: 4,
			    maxlength: 15
			}
	},
	
	messages:{
			newpass :{
				required:"This is a required field.",
				minlength:"Too short"
			},
			oldpass:"This is a required field.",
			confirmpass:{
				equalTo:"The passwords do not match.",
				required:"This is a required field."
			}
	}	
}
//-----------------------------------leaveRequest.jsp-------------------------------------//
var leave	=	{
		rules: {
				fullname : "required",
				projectid : "required",
				leave_type : "required",
				start : "required",
				end : "required",
				leave_reason : "required"
			
			  },
		

	messages : {
		fullname : "This is a required field.",
		projectid : "This is a required field.",
		leave_type : "This is a required field.",
		start : "This is a required field.",
		end : "This is a required field.",
		leave_reason : "This is a required field."

	}	
}

//-----------------------------------registration.jsp(both)-------------------------------------//
var register = {
	rules : {

		photo:"required",
		firstName:"required",
		lastName:"required",
		father:"required",
		mother :"required",
		dob:"required",
		gender:"required",
		pan:{
			required:true,
			maxlength:10,
			minlength:10
		},
		houseno1:"required",
		street1:"required",
		city1:"required",
		state1:"required",
		country1:"required",
		pincode1:{
			required:true,
			number:true
		},
		houseno2:"required",
		street2:"required",
		city2:"required",
		state2:"required",
		country2:"required",
		pincode2:{
			required:true,
			number:true
		},
		
		landline:{
			required:true,
			number:true,
			maxlength:15
		},
		mobile:{
			required:true,
			number:true,
			maxlength:10,
			minlength:10
		},
		pemail:{
			required:true,
			email:true
		},
		mstatus:"required",
		depend:{
			required:true,
			number:true,
			maxlength:2,
		},
		religion:"required",
		blood:"required",
//		
		qualification:"required",
		college:"required",
		year:{
			required:true,
			number:true,
			maxlength:4,
			minlength:4
		},
		grade:"required",
		percentage:{
			required:true,
			number:true
		},
//		
		
		idtype:"required",
		idno:"required",
		file:"required",
//	
		appoint:"required",
		confirm:"required",
		probation:
			{
			required:true,
			number:true,
			maxlength:1
			},
//		
		bank:"required",
		branch:"required",
		account:{
			required:true,
			number:true
		},
		ifsc:"required",
//		
		family_name:"required",
		family_address:"required",
		family_relation:"required",
		family_dob:"required",
		
	},

	messages : {
		
		photo:"This field is required.",
		firstName:"This field is required.",
		lastName:"This field is required.",
		father:"This field is required.",
		mother :"This field is required.",
		dob:"This field is required.",
		gender:"This field is required.",
		pan:{
			required:"This field is required.",
			minlength:"Too short."
		},
		houseno1:"This field is required.",
		street1:"This field is required.",
		city1:"This field is required.",
		state1:"This field is required.",
		country1:"This field is required.equired",
		pincode1:{
			required:"This field is required.",
			number:"Only didgits allowed."
		},
		houseno2:"This field is required.",
		street2:"This field is required.",
		city2:"This field is required.",
		state2:"This field is required.",
		country2:"This field is required.",
		pincode2:{
			required:"This field is required.",
			number:"Only digits allowed."
		},
		
		landline:{
			required:"This field is required.",
			number:"Only digits allowed.",
		},
		mobile:{
			required:"This field is required.",
			number:"Only numbers allowed.",
			minlength:"Too short."
		},
		pemail:{
			required:"This field is required.",
			email:"Please include proper @ and ."
		},
		depend:{
			required:"This field is required.",
			number:"Only digits allowed",
		},
		religion:"This field is required.",
		blood:"This field is required.",
		
//		
		qualification:"This field is required.",
		college:"This field is required.",
		year:{
			required:"This field is required.",
			number:"Only digits allowed",
			minlength:"Too short"
		},
		grade:"This field is required.",
		percentage:{
			required:"This field is required.",
			number:"Only digits allowed"
		},
//		
		
		idtype:"This field is required.",
		idno:"This field is required.",
		file:"This field is required.",
//		
		appoint:"This field is required.",
		confirm:"This field is required.",
		probation:
			{
			required:"This field is required.",
			number:"Only digits allowed"
			},
		
//		
		bank:"This field is required.",
		branch:"This field is required.",
		account:{
				required:"This field is required.",
				number:"Only digits allowed."
			},
		ifsc:"This field is required.",
//		
		family_name:"This field is required.",
		family_address:"This field is required.",
		family_relation:"This field is required.",
		family_dob:"This field is required.",
		
	}
}






