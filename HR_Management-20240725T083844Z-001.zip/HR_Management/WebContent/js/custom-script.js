/**
 * Name: custom-script file.
 * Description: script functions for checking validations
 */

/*************************************************************************/

	function checkValue(p_this) {
		var a = $(p_this).val();
		a = parseInt(a);
		if (a > 100) {
			$(p_this).val("");
		}
	}

/*************************************************************************/

	function check10DigitMobile(p_element){
		if(p_element.value ==""){
			$(p_element).next("span").remove();
			return false;
		}
		if(p_element.value.length <10 ){
			$(p_element).next("span").remove();
			$(p_element).after('<span style="color:red">Mobile Number should be 10 digit !</span>');
			$(p_element).css('border-color','red');
			return false;
		}
		$(p_element).next("span").remove();
		return true;
	
	}
	
/*************************************************************************/	
	
	function validateEmail(p_this) {
		var l_val = $(p_this).val();
		var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
		if (!emailReg.test(l_val)) {
			$(p_this).next("span").remove();
			$(p_this).after('<span style="color:red">Invalid email address !</span>');
			$(p_this).css('border-color','red');
			return false;
		}else{
			$(p_this).next("span").remove();
			return true;
		}
	}
	