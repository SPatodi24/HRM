/**
 * This class deals only with login of user and administrator.
 * login page verification for user credentials 
 */

package com.apar.controller.user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.apar.dbconnection.ConnectionProvider;
import com.apar.dbconnection.DbUtil;

// @WebServlet("/LoginActivity")
public class LoginActivity extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	private Connection  conn			=	null;
	private Statement   st				=	null;
	private ResultSet   rs				=	null;

	public LoginActivity() {
		super();
	}

	/**
	 * The <code>doPost</code> is created for verifying the user credentials
	 * on login from the database.
	 * 
	 * @param l_userid
	 * 		  user login email/mobile number/employee ID
	 * 
	 * @param l_pwd 
	 * 		  password
	 * 
	 */
	
	
	protected void doPost(HttpServletRequest p_request, HttpServletResponse p_response)	throws ServletException, IOException {
		
		p_response.setContentType("text/html");

		PrintWriter  out 		=	 p_response.getWriter();
		String       l_userid 	=	 p_request.getParameter("uname").trim();
		String       l_pwd 		=	 p_request.getParameter("pass").trim();

		
		
		Map <String,String> map	=	 new HashMap<String,String>();

		map.put("username", l_userid);
		map.put("password", l_pwd);

		try{
			conn = ConnectionProvider.getConnection();
			st		=	conn.createStatement();
			rs		=	st.executeQuery("select l.login_id,company_email,mobile,password,emp_type,p.emp_id from emp_apar_details a,emp_personal_details p,emp_login l where (a.emp_id=p.emp_id and a.emp_id=l.login_id) and ((login_id='"+l_userid+"' OR company_email='"+l_userid+"' OR mobile='"+l_userid+"') and password='"+l_pwd+"')");

			
			if(rs.next())
			{
				String loginid	=	rs.getString(1);
				String cemail	=	rs.getString(2);
				String mobile	=	rs.getString(3);
				String pwd		=	rs.getString(4);
				String type		=	rs.getString(5);
				String id		=	rs.getString(6);
				
				
				if((l_userid.equals(loginid) || l_userid.equals(cemail) || l_userid.equals(mobile)) && l_pwd.equals(pwd))
				{
					HttpSession session=p_request.getSession();
					session.setAttribute("id",id);
					
						if(type.equals("Administrator"))
								p_response.sendRedirect("indexAdmin.jsp");
						else{
							
								p_response.sendRedirect("index.jsp");
							}
				}
				
				
			}else{
//				error message.. you have not been registered by admin!! try again!!
				//out.print("Sorry, username or password error!");
				//p_request.getRequestDispatcher("login.jsp").include(p_request, p_response);
			p_response.sendRedirect("login.jsp?error=1");
		
		}
			
			
			
		}
		catch(Exception e)
		{
			out.println(e.getMessage());
		}
		finally {
	           DbUtil.close(st);
	           DbUtil.close(conn);
	           DbUtil.close(rs);
     }
	}
}
