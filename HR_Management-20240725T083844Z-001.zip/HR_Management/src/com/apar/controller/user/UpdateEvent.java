package com.apar.controller.user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.apar.common.CommonFunction;
import com.apar.dbconnection.ConnectionProvider;
import com.apar.dbconnection.DbUtil;
import com.mysql.jdbc.PreparedStatement;

//@WebServlet("/UpdateEvent")
public class UpdateEvent extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection   conn		=	null;
	private Statement    st			=	null;
	
	String l_venue	=	null;
	String l_desc		=	null;
	String l_photo	=	null;
	Date   l_start	=	null;
	Date   l_end		=	null;
	
	Map <String, Object> l_request_map			=	null;
	Enumeration<String>  l_enum_parameter		=	null;
	 
    
    public UpdateEvent() {
        super();
       
    }

	
	protected void doPost(HttpServletRequest p_request, HttpServletResponse p_response) throws ServletException, IOException {
		p_response.setContentType("text/html");
		PrintWriter  out 		=	 p_response.getWriter();
		
		l_request_map		=	new HashMap<String, Object>();
		l_enum_parameter	=	p_request.getParameterNames();
		
		while(l_enum_parameter.hasMoreElements())
		{
			String parameterName	=  l_enum_parameter.nextElement();
			String parameterValue	=  p_request.getParameter(parameterName);
			l_request_map.put(parameterName, parameterValue);
		}
		System.out.println("id:::"+l_request_map.get("eid"));
		l_venue	=	CommonFunction.convertNullValues((String) l_request_map.get("venue"));
		l_desc	=	CommonFunction.convertNullValues((String) l_request_map.get("edesc"));
		l_photo	=	CommonFunction.convertNullValues((String) l_request_map.get("photo"));
		
		l_request_map.put("venue",l_venue);
		l_request_map.put("edesc",l_desc);
		l_request_map.put("photo",l_photo);
		
		/*for (Map.Entry<String, Object> entry : l_request_map.entrySet()) {
		     System.out.println("Key = " + entry.getKey() + " , Value = " + entry.getValue());
		}*/
		
		try{
			conn 	= 	ConnectionProvider.getConnection();
			st		=	conn.createStatement();
			
			
			String sql	=	"UPDATE events  SET e_name=?, venue=?, e_start=?, e_end=?, e_desc=?, photo=?  WHERE event_id=?";
			PreparedStatement ps 	=	(PreparedStatement) conn.prepareStatement(sql);
			ps.setObject(1,l_request_map.get("ename") );
			ps.setObject(2,l_request_map.get("venue") );
			ps.setObject(3,l_request_map.get("estart") );
			ps.setObject(4,l_request_map.get("eend") );
			ps.setObject(5,l_request_map.get("edesc") );
			ps.setObject(6,l_request_map.get("photo") );
			ps.setObject(7,l_request_map.get("eid") );	
			
			ps.executeUpdate();
			System.out.println("event updated");
			p_response.sendRedirect("ListEventsAdmin.jsp");
		}catch(Exception e)
		{
			out.println(e.getMessage());
		}
		finally {
	           DbUtil.close(st);
	           DbUtil.close(conn);
        }
	}

}
