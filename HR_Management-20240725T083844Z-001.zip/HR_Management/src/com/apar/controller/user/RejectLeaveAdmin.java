package com.apar.controller.user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.apar.dbconnection.ConnectionProvider;
import com.apar.dbconnection.DbUtil;
import com.mysql.jdbc.PreparedStatement;


//@WebServlet("/RejectLeaveAdmin")
public class RejectLeaveAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private	Connection        conn			=	null;  
	String l_id	=	null;
	String l_startd	=	null;
	String l_reason	=	null;
	
    public RejectLeaveAdmin() {
        super();
       
    }

	
	protected void doPost(HttpServletRequest p_request, HttpServletResponse p_response) throws ServletException, IOException {
		p_response.setContentType("text/html");
		PrintWriter  out	=	p_response.getWriter();
		
		l_startd	=	p_request.getParameter("sdate");
		l_reason	=	p_request.getParameter("reject_reason");
		System.out.println(l_startd);
		
		l_id	=	p_request.getParameter("empid");
		System.out.println("fethcing id from jsp:::"+l_id);
		
		try{
			conn = ConnectionProvider.getConnection();
			String sql= "update emp_leave_request set status=? reject_reason=? where emp_id=? and start=?";
			
			PreparedStatement ps 	=	(PreparedStatement) conn.prepareStatement(sql);
						
			ps.setObject(1,"Rejected");
			ps.setObject(2,l_reason );
			ps.setObject(3,l_id );
			ps.setObject(4,l_startd);
			ps.executeUpdate();
			
			System.out.println("leave rejected : db updated ");
			
			p_response.sendRedirect("managerLeaveApprovalAdmin.jsp");		
		}
	catch(Exception e)
		{
			out.println(e.getMessage());
		}
		finally {
					DbUtil.close(conn);
					
				}
	}

}
