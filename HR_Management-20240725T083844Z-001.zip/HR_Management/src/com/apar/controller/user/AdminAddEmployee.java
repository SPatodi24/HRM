package com.apar.controller.user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.apar.common.IdGeneratorFactory;
import com.apar.dbconnection.ConnectionProvider;
import com.apar.dbconnection.DbUtil;
import com.mysql.jdbc.PreparedStatement;



//@WebServlet("/AdminAddEmployee")
public class AdminAddEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private Connection   conn		=	null;
	private Statement    st			=	null;
	   
	Map <String, Object> l_request_map			=	null;
	Enumeration<String>  l_enum_parameter		=	null;
	String l_identifier	=	null;
	String l_identifier_employ	=	null;
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
	Date date = new Date(System.currentTimeMillis());
	
    public AdminAddEmployee() {
        super();
    }

	protected void doPost(HttpServletRequest p_request, HttpServletResponse p_response) throws ServletException, IOException {
		p_response.setContentType("text/html");
		PrintWriter  out 		=	 p_response.getWriter();
		
		try{
			conn 	= 	ConnectionProvider.getConnection();
			st		=	conn.createStatement();
			
			l_request_map		=	new HashMap<String, Object>();
			l_enum_parameter	=	p_request.getParameterNames();
			
			while(l_enum_parameter.hasMoreElements())
			{
				String parameterName	=  l_enum_parameter.nextElement();
				String parameterValue	=  p_request.getParameter(parameterName);
				l_request_map.put(parameterName, parameterValue);
			}
		
			PreparedStatement ps 	=	(PreparedStatement) conn.prepareStatement("insert into emp_personal_details(emp_id) values(?)");
			PreparedStatement ps1 	= 	(PreparedStatement) conn.prepareStatement("insert into emp_login(login_id,password) values(?,?)");
			PreparedStatement ps2 	= 	(PreparedStatement) conn.prepareStatement("insert into emp_apar_details(id_company,emp_id,company_email) values(?,?,?)");
			PreparedStatement ps3 	= 	(PreparedStatement) conn.prepareStatement("insert into emp_employment_details(id_employment,emp_id,date_of_appointment) values(?,?,?)");
			
			ps.setObject(1, l_request_map.get("empid"));
			
			ps1.setObject(1, l_request_map.get("empid"));
			ps1.setObject(2, l_request_map.get("pswd"));
			
			l_identifier	= 	IdGeneratorFactory.generateUniqueId("C", null);
			ps2.setObject(1,l_identifier );
			ps2.setObject(2,l_request_map.get("empid"));
			ps2.setObject(3,l_request_map.get("mailid") );
			
//			employment table is required as for searching an employee, the employement table is used to check for DOJ
			l_identifier_employ 	=	IdGeneratorFactory.generateUniqueId("C", null);
			ps3.setObject(1,l_identifier_employ );
			ps3.setObject(2,l_request_map.get("empid"));
			ps3.setObject(3,sdf.format(date));			
			
			ps.executeUpdate();
			ps1.executeUpdate();
			ps2.executeUpdate();
			ps3.executeUpdate();
			
			System.out.println("employee added");
			p_response.sendRedirect("addEmployee.jsp?success=ok");
		
		}catch(Exception e)
		{
			out.println(e.getMessage());
		}
		finally {
	           DbUtil.close(st);
	           DbUtil.close(conn);
        }
	}

}
