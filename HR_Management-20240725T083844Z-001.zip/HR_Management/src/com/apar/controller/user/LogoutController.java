package com.apar.controller.user;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LogoutController
 */
//@WebServlet("/LogoutController")
public class LogoutController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public LogoutController() {
        super(); 
    }

	protected void doGet(HttpServletRequest p_request, HttpServletResponse p_response) throws ServletException, IOException {
		p_response.setContentType("text/html");
		PrintWriter out = p_response.getWriter();
		
		HttpSession session = p_request.getSession();
		session.removeAttribute("id");
	    session.invalidate();
		p_response.sendRedirect("login.jsp");
		//System.out.print("You are successfully logged out!");
		
		
		out.close();
	}

}
