package com.apar.controller.user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.apar.common.CommonFunction;
import com.apar.common.IdGeneratorFactory;
import com.apar.dbconnection.ConnectionProvider;
import com.apar.dbconnection.DbUtil;
import com.mysql.jdbc.PreparedStatement;
import java.io.File;
import java.io.FileInputStream;

//@WebServlet("/NewNews")
public class NewNews extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private	Connection        conn			=	null;
	
	Map <String, Object> l_request_map		=	null;
	Enumeration<String>  l_enum_parameter	=	null;
  
	String l_identifier_news	=	null;
	
	String l_desc	=	null;
	String l_photo	=	null;
	Date   l_date	=	null;
	
	String path = "C:\\wildfly-8.0.0.Final\\bin\\photos";
    
    public NewNews() {
        super();
      
    }

	
	protected void doPost(HttpServletRequest p_request, HttpServletResponse p_response) throws ServletException, IOException {
		p_response.setContentType("text/html");
		PrintWriter  out 		=	 p_response.getWriter();
		
		l_request_map		=	new HashMap<String, Object>();
		l_enum_parameter	=	p_request.getParameterNames();
		
		while(l_enum_parameter.hasMoreElements())
		{
			String parameterName	=  l_enum_parameter.nextElement();
			String parameterValue	=  p_request.getParameter(parameterName);
			l_request_map.put(parameterName, parameterValue);
		}
		
		l_desc	=	CommonFunction.convertNullValues((String) l_request_map.get("ndesc"));
		l_photo	=	CommonFunction.convertNullValues((String) l_request_map.get("nphoto"));
		path	=	path.concat((String) l_request_map.get("nphoto"));
		
		l_request_map.put("ndesc",l_desc);
		l_request_map.put("nphoto",path);
		 
//		System.out.println("testing photo path::"+l_request_map.get("nphoto") );
		 
		try{
			conn = ConnectionProvider.getConnection();

			l_identifier_news 		= 	IdGeneratorFactory.generateUniqueId("NEWS", null);
			PreparedStatement ps1 	= 	(PreparedStatement) conn.prepareStatement("insert into news values(?,?,?,?,?) ");			
			
			ps1.setObject(1,l_identifier_news );
			ps1.setObject(2,l_request_map.get("nname") );
			ps1.setObject(3,l_request_map.get("ndate") );
			ps1.setObject(4,l_request_map.get("l_photo") );
//			ps1.setBinaryStream(4, fin, (int) imgfile.length());
			ps1.setObject(5,l_request_map.get("l_desc") );
			ps1.executeUpdate();
			
			p_response.sendRedirect("listNewsAdmin.jsp");
		
			System.out.println("news added");
	}
	catch(Exception e)
		{
			out.println(e.getMessage());
		}
		finally {
					DbUtil.close(conn);
				}	
	}

}
