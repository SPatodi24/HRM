package com.apar.controller.user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.apar.common.CommonFunction;
import com.apar.common.IdGeneratorFactory;
import com.apar.dbconnection.ConnectionProvider;
import com.apar.dbconnection.DbUtil;
import com.mysql.jdbc.PreparedStatement;


//@WebServlet("/UpdateEmpDetailsAdmin")
public class UpdateEmpDetailsAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection   conn		=	null;
	private Statement    st			=	null;
	
//	personal details fields
	String      	  l_empid 			=	null;		//PK
	String            l_fname 			=	null;
	String			  l_mname			=	null; 				
	String            l_lname 			=	null;
	String 			  l_fathername		=   null;
	String 		 	  l_mothername		=   null;
	String 			  l_dob				=   null;		//date
	String 			  l_gender			=   null;
	String			  l_pan				=	null;
	String 			  l_peraddress		=   null;			//----used
	String 			  l_landline		=   null;
	String 			  l_mobile			=   null;
	String 			  l_personalemail   =   null;
	String 			  l_martial			=   null;
	String 			  l_marriage		=   null;		//date
	String 			  l_dependents		=	null;
	String 			  l_spouse 			=   null;
	String 			  l_religion		=   null;
	String 			  l_bloodgroup		=   null;

// permanent address fields-----------------------------used
	String			  l_per_houseno		=	null;
	String			  l_per_street		=	null;
	String			  l_per_city		=	null;
	String			  l_per_state		=	null;
	String			  l_per_country		=	null;
	String			  l_per_pincode		=	null;
//	-------------------------------------------------------

	String 			  l_confirmation	= null;		//date
	String			  l_probation		= null;
	String 			  l_resignation		= null;		//date
	String 			  l_branch			= null;
	String 			  l_designation		= null;
	String 			  l_dept			= null;
	String 			  l_grade			= null;

	//experience fields
	String[] 		  l_companyname		= null;
	String[] 		  l_location		= null;
	String[] 		  l_expdesign		= null;
	String[]		  l_from			= null;		//date
	String[]		  l_to				= null;		//date
	
//family fields
	String[] 		  l_family_name		= null;
	String[] 		  l_family_address	= null;
	String[]		  l_family_relation	= null;
	String[] 		  l_family_dob		= null;		//date
		
//id proof fields 
	String[] 		  l_id_type			= null;
	String[] 		  l_expiry			= null;			//date
	String[]		  l_number			= null;
	String[] 		  l_link			= null;

//qualification fields		 
	String[] 		  l_qualification	= null;
	String[] 		  l_university		= null;
	String[]	 	  l_year			= null;		//int
	String[] 		  l_percent			= null;		//float
	String[] 		  l_qgrade			= null;
	
// nominee fields
	String[] l_nominee_name		=	null;
	String[] l_nominee_relation	=	null;
	String[] l_nominee_address	=	null;
	String[] l_nominee_dob		=	null;
	String[] l_nominee_share	=	null;


	Map <String, Object> l_request_map			=	null;
	Enumeration<String>  l_enum_parameter		=	null;
	 
    public UpdateEmpDetailsAdmin() {
        super();
     
    }

	protected void doPost(HttpServletRequest p_request, HttpServletResponse p_response) throws ServletException, IOException {
		p_response.setContentType("text/html");
		PrintWriter  out 		=	 p_response.getWriter();
		
		l_request_map		=	new HashMap<String, Object>();
		l_enum_parameter	=	p_request.getParameterNames();
		
		while(l_enum_parameter.hasMoreElements())
		{
			String parameterName	=  l_enum_parameter.nextElement();
			String parameterValue	=  p_request.getParameter(parameterName);
			l_request_map.put(parameterName, parameterValue);
		}
		System.out.println("before map display");
		
//		fetching address fields to concat and make permanent address
		l_per_houseno	=	 p_request.getParameter("houseno1");
		l_per_street	=	 p_request.getParameter("street1");
		l_per_city		=	 p_request.getParameter("city1");	
		l_per_state		=	 p_request.getParameter("state1");
		l_per_country	=	 p_request.getParameter("country1");
		l_per_pincode	=	 p_request.getParameter("pincode1");
		l_peraddress	=	 l_per_houseno+","+l_per_street+","+l_per_city+","+l_per_state+","+l_per_country+","+l_per_pincode;
		
		l_request_map.put("permanent_address", l_peraddress);
		

//		checking for null values in the text box
			l_mname 		= CommonFunction.convertNullValues((String) l_request_map.get("middleName"));
			l_marriage 		= CommonFunction.convertNullValues((String) l_request_map.get("mdate"));
			l_spouse 		= CommonFunction.convertNullValues((String) l_request_map.get("spouse"));

			l_resignation	= CommonFunction.convertNullValues((String) l_request_map.get("earl_resign"));
			l_branch 		= CommonFunction.convertNullValues((String) l_request_map.get("earl_branch"));
			l_designation 	= CommonFunction.convertNullValues((String) l_request_map.get("earl_designation"));
			l_dept 			= CommonFunction.convertNullValues((String) l_request_map.get("earl_dept"));
			l_grade 		= CommonFunction.convertNullValues((String) l_request_map.get("earl_grade"));
		
			
//	putting values in map after checking for null		
			l_request_map.put("middleName",l_mname);
			l_request_map.put("mdate",l_marriage);
			l_request_map.put("spouse",l_spouse);
			l_request_map.put("earl_resign",l_resignation);
			l_request_map.put("earl_branch",l_branch);
			l_request_map.put("earl_designation",l_designation);
			l_request_map.put("earl_dept",l_dept);
			l_request_map.put("earl_grade",l_grade);

	
		/*for (Map.Entry<String, Object> entry : l_request_map.entrySet()) {
		     System.out.println("Key = " + entry.getKey() + " , Value = " + entry.getValue());
		}
	*/
			/**
			 * 	fetching multiple fields control values and storing them in array
			 */
											 l_nominee_name		=	p_request.getParameterValues("nominee_name");
											 l_nominee_relation	=	p_request.getParameterValues("nominee_relation");
											 l_nominee_address	=	p_request.getParameterValues("nominee_address");
											 l_nominee_dob		=	p_request.getParameterValues("nominee_dob");
											 l_nominee_share	=	p_request.getParameterValues("nominee_percentage");

//			  			qualification fields
											 l_qualification	= p_request.getParameterValues("qualification");
											 l_university		= p_request.getParameterValues("college");
											 l_year				= p_request.getParameterValues("year");		//int
											 l_percent			= p_request.getParameterValues("percentage");		
											 l_qgrade			= p_request.getParameterValues("grade");
									
//							id proof fields
											 l_id_type			=	p_request.getParameterValues("idtype");
											 l_expiry			=	p_request.getParameterValues("expiry");
											 l_number			=	p_request.getParameterValues("idno");
											 l_link				=	p_request.getParameterValues("file");

//							work experience fields		
											 l_companyname		=	p_request.getParameterValues("org_company");	
											 l_location			=	p_request.getParameterValues("org_location");	
											 l_expdesign		=	p_request.getParameterValues("org_designation");
											 l_from				=	p_request.getParameterValues("fromdate");	
											 l_to				=	p_request.getParameterValues("todate");
											 
//							family fields
											 l_family_name		=	p_request.getParameterValues("family_name");
											 l_family_address	=	p_request.getParameterValues("family_address");
											 l_family_relation	=	p_request.getParameterValues("family_relation");
											 l_family_dob		=	p_request.getParameterValues("family_dob");
				/**
				 *  	combining and executing the code
				*/		
try{
	conn = ConnectionProvider.getConnection();
	
String sql= " UPDATE emp_personal_details  SET  firstname=?, middlename=?, lastname=?, father_name=?, mother_name=?, date_of_birth=?, gender=?, PAN=?, permanent_address=?, landline=?, mobile=?,personal_email=?, martial_status=?, marriage_date=?, no_of_dependents=? , spouse_name=? , religion=?, blood_group=? WHERE emp_id=?";
	
	PreparedStatement ps 	=	(PreparedStatement) conn.prepareStatement(sql);

	ps.setObject(1,l_request_map.get("firstName") );
	ps.setObject(2,l_request_map.get("middleName") );
	ps.setObject(3,l_request_map.get("lastName") );
	ps.setObject(4,l_request_map.get("father") );
	ps.setObject(5,l_request_map.get("mother") );
	ps.setObject(6,l_request_map.get("dob"));
	ps.setObject(7,l_request_map.get("gender") );
	ps.setObject(8,l_request_map.get("pan") );
	ps.setObject(9,l_peraddress );
	ps.setObject(10,l_request_map.get("landline") );
	ps.setObject(11,l_request_map.get("mobile") );
	ps.setObject(12,l_request_map.get("pemail") );
	ps.setObject(13,l_request_map.get("mstatus") );
	ps.setObject(14,l_request_map.get("mdate") );
	ps.setObject(15,l_request_map.get("depend") );
	ps.setObject(16,l_request_map.get("spouse") );
	ps.setObject(17,l_request_map.get("religion") );
	ps.setObject(18,l_request_map.get("blood"));
	ps.setObject(19,l_request_map.get("empid"));
	ps.executeUpdate();
//--------------------------------------------------------------------------------------------------------------
	
	PreparedStatement ps1 	= 	(PreparedStatement) conn.prepareStatement("UPDATE emp_address SET  house_number=?, street=?, city=?, state=?, country=?, pincode=?   WHERE emp_id=?");			
	ps1.setObject(1,l_request_map.get("houseno2") );
	ps1.setObject(2,l_request_map.get("street2") );
	ps1.setObject(3,l_request_map.get("city2") );
	ps1.setObject(4,l_request_map.get("state2") );
	ps1.setObject(5,l_request_map.get("country2") );
	ps1.setObject(6,l_request_map.get("pincode2") );
	ps1.setObject(7,l_request_map.get("empid") );
	ps1.executeUpdate();
//--------------------------------------------------------------------------------------------------------------
	for(int i=0;i<l_qualification.length;i++) {
		 String test_year = l_year[i];
		 int q_year = Integer.parseInt(test_year);
		
		 String test_per = l_percent[i];
		 Float q_per = Float.parseFloat(test_per);
		 
	PreparedStatement ps2	   = (PreparedStatement) conn.prepareStatement(
			"UPDATE emp_qualifications    SET   qualification=?, university=?, year_of_passing=?, percentage=?, grade=?    WHERE emp_id=?");
	ps2.setObject(1, l_qualification[i]);
	ps2.setObject(2, l_university[i]);
	ps2.setObject(3, q_year);
	ps2.setObject(4, q_per);
	ps2.setObject(5, l_qgrade[i]);
	ps2.setObject(6, l_request_map.get("empid"));
	ps2.executeUpdate();
	}
//--------------------------------------------------------------------------------------------------------------	
	for(int i=0;i<l_id_type.length;i++) {
		l_expiry[i]	=	CommonFunction.convertNullValues((String) l_request_map.get("expiry"));
		PreparedStatement ps3	= (PreparedStatement) conn.prepareStatement(
				"UPDATE emp_id_proof   SET  proof_type=?, expiry_date=?, proof_number=?, file_link=?   WHERE   emp_id=? ");
		
		ps3.setObject(1, l_id_type[i]);
		ps3.setObject(2, l_expiry[i]);
		ps3.setObject(3, l_number[i]);
		ps3.setObject(4, l_link[i]);
		ps3.setObject(5, l_request_map.get("empid"));
		ps3.executeUpdate();
		}
		
	//--------------------------------------------------------------------------------------------------------------
		PreparedStatement ps4 	= (PreparedStatement) conn.prepareStatement(
				"UPDATE emp_employment_details  SET   date_of_appointment=?, confirmation_date=?, probation_period=?, previous_org_resignation_date=?, previous_org_branch=?, previous_org_designation=?, previous_org_department=?, grade=?    WHERE   emp_id=? ");

		ps4.setObject(1, l_request_map.get("appoint"));	
		ps4.setObject(2, l_request_map.get("confirm"));	
		ps4.setObject(3, l_request_map.get("probation"));	
		ps4.setObject(4, l_request_map.get("earl_resign"));	
		ps4.setObject(5, l_request_map.get("earl_branch"));	
		ps4.setObject(6, l_request_map.get("earl_designation"));	
		ps4.setObject(7, l_request_map.get("earl_dept"));	
		ps4.setObject(8, l_request_map.get("earl_grade"));	
		ps4.setObject(9, l_request_map.get("empid"));
		ps4.executeUpdate();
		
//		--------------------------------------------------------------------------------------------------------------
		
		PreparedStatement ps5 	= (PreparedStatement) conn.prepareStatement(
				"UPDATE emp_financial_details   SET   bank_name=?, bank_branch=?, account_number=?, ifsc=?     WHERE emp_id=?");
		
		ps5.setObject(1, l_request_map.get("bank"));
		ps5.setObject(2, l_request_map.get("branch"));
		ps5.setObject(3, l_request_map.get("account"));
		ps5.setObject(4, l_request_map.get("ifsc"));
		ps5.setObject(5, l_request_map.get("empid"));
		ps5.executeUpdate();
//		--------------------------------------------------------------------------------------------------------------
		for(int i=0;i<l_companyname.length;i++) {	
		PreparedStatement ps6 	= (PreparedStatement) conn.prepareStatement(
				"UPDATE emp_work_experience     SET   company_name=?, location=?, designation=?, from_date=?, to_date=?     WHERE   emp_id=? ");
		
		ps6.setObject(1, l_companyname[i]);
		ps6.setObject(2, l_location[i]);
		ps6.setObject(3, l_expdesign[i]);
		ps6.setObject(4, l_from[i]);
		ps6.setObject(5, l_to[i]);
		ps6.setObject(6, l_request_map.get("empid"));
		ps6.executeUpdate();
		}
	//--------------------------------------------------------------------------------------------------------------
		
		for(int i=0;i<l_family_name.length;i++) {
			PreparedStatement ps7 = (PreparedStatement) conn.prepareStatement("UPDATE emp_family_details    SET   name=?, address=?, relationship=?, dob=?    WHERE emp_id=?");
			
			ps7.setObject(1, l_family_name[i]);
			ps7.setObject(2, l_family_address[i]);
			ps7.setObject(3, l_family_relation[i]);
			ps7.setObject(4, l_family_dob[i]); 
			ps7.setObject(5, l_request_map.get("empid"));
			ps7.executeUpdate();
			}
		//--------------------------------------------------------------------------------------------------------------
			
			for(int i=0;i<l_nominee_name.length;i++) {
				System.out.println("in nominee::"+i);	
			PreparedStatement ps8 	= 	(PreparedStatement) conn.prepareStatement("UPDATE emp_nominee      SET   name=?, address=?, relationship=?, dob=?, share_percent=?     WHERE   emp_id=? ");
			
			ps8.setObject(1,l_nominee_name[i] );
			ps8.setObject(2,l_nominee_address[i] );
			ps8.setObject(3,l_nominee_relation [i]);
			ps8.setObject(4,l_nominee_dob[i]);
			ps8.setObject(5,l_nominee_share[i] );
			ps8.setObject(6,l_request_map.get("empid") );
			ps8.executeUpdate();
			}
			
		//--------------------------------------------------------------------------------------------------------------
			
		PreparedStatement ps9 	= 	(PreparedStatement) conn.prepareStatement(
				"UPDATE emp_apar_details  SET   payroll_id=?, position=?, department=?, company_email=?, salary=?, status=?, reporting_manager=?, emp_type=?     WHERE emp_id=?");
	
		ps9.setObject(1, l_request_map.get("payroll"));			
		ps9.setObject(2, l_request_map.get("position"));
		ps9.setObject(3, l_request_map.get("dept"));
		ps9.setObject(4, l_request_map.get("cemail"));
		ps9.setObject(5, l_request_map.get("salary"));
		ps9.setObject(6, l_request_map.get("status"));
		ps9.setObject(7, l_request_map.get("manager"));
		ps9.setObject(8, l_request_map.get("type"));
		ps9.setObject(9, l_request_map.get("empid"));	
		ps9.executeUpdate();

		//--------------------------------------------------------------------------------------------------------------
		String roles[] = p_request.getParameterValues("role");
		
		PreparedStatement ps11 = (PreparedStatement) conn.prepareStatement("insert into user_role_map values(?,?,?)");
		for (int i = 0; i < roles.length; i++) {
			String l_identifier_role = IdGeneratorFactory.generateUniqueId("ER", null);
			ps11.setObject(1, roles[i]);
			ps11.setObject(2, l_request_map.get("empid"));
			ps11.setObject(3, l_identifier_role);
			ps11.executeUpdate();
		}
		p_response.sendRedirect("profileAdmin.jsp");
		System.out.println("in user update profile by admin");
		
	}
catch(Exception e)
	{
		out.println(e.getMessage());
	}
	finally {
				DbUtil.close(conn);
			}	

	}

}
