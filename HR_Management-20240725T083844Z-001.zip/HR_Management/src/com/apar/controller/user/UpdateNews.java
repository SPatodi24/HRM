package com.apar.controller.user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.apar.common.CommonFunction;
import com.apar.dbconnection.ConnectionProvider;
import com.apar.dbconnection.DbUtil;
import com.mysql.jdbc.PreparedStatement;


//@WebServlet("/UpdateNews")
public class UpdateNews extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private Connection   conn		=	null;
	private Statement    st			=	null;
	String l_desc	=	null;
	String l_photo	=	null;
	Date   l_date	=	null;
	
	Map <String, Object> l_request_map			=	null;
	Enumeration<String>  l_enum_parameter		=	null;
	 
    public UpdateNews() {
        super();
        
    }

    protected void doPost(HttpServletRequest p_request, HttpServletResponse p_response) throws ServletException, IOException {
	
    	p_response.setContentType("text/html");
		PrintWriter  out 		=	 p_response.getWriter();
		
		l_request_map		=	new HashMap<String, Object>();
		l_enum_parameter	=	p_request.getParameterNames();
		
		while(l_enum_parameter.hasMoreElements())
		{
			String parameterName	=  l_enum_parameter.nextElement();
			String parameterValue	=  p_request.getParameter(parameterName);
			l_request_map.put(parameterName, parameterValue);
		}
		
		l_desc	=	CommonFunction.convertNullValues((String) l_request_map.get("ndesc"));
		l_photo	=	CommonFunction.convertNullValues((String) l_request_map.get("nphoto"));
		
		l_request_map.put("ndesc",l_desc);
		l_request_map.put("nphoto",l_photo);
		
		try{
			conn 	= 	ConnectionProvider.getConnection();
			st		=	conn.createStatement();
			
			
			String sql	=	"UPDATE news   SET  n_name=? , n_date=?, n_photo=?, n_desc=?  WHERE news_id=?";
			PreparedStatement ps 	=	(PreparedStatement) conn.prepareStatement(sql);
			ps.setObject(1,l_request_map.get("nname") );
			ps.setObject(2,l_request_map.get("ndate") );
			ps.setObject(3,l_request_map.get("nphoto") );
			ps.setObject(4,l_request_map.get("ndesc") );
			ps.setObject(5,l_request_map.get("nid") );	
			ps.executeUpdate();
			System.out.println("news updated");
			p_response.sendRedirect("listNewsAdmin.jsp");
		}catch(Exception e)
		{
			out.println(e.getMessage());
		}
		finally {
	           DbUtil.close(st);
	           DbUtil.close(conn);
        }
	}

}
