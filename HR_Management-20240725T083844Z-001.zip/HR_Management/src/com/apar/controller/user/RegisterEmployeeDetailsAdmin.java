package com.apar.controller.user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.apar.common.CommonFunction;
import com.apar.common.IdGeneratorFactory;
import com.apar.dbconnection.ConnectionProvider;
import com.apar.dbconnection.DbUtil;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;


//@WebServlet("/RegisterEmployeeDetailsAdmin")
public class RegisterEmployeeDetailsAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private	Connection        conn			=	null;
	
	Map <String, Object> l_request_map		=	null;
	Enumeration<String>  l_enum_parameter	=	null;

//	IdGeneratorFactory Fields
	String l_identifier_personal		=	null;
	String l_identifier_add				=	null;
	String l_identifier_qualification	=	null;
	String l_identifier_proof			=	null;
	String l_identifier_employment		=	null;
	String l_identifier_financial		=	null;
	String l_identifier_experience		=	null;
	String l_identifier_family			=	null;
	String l_identifier_nominee			=	null;
	String l_identifier_leave			=	null;
	
	String l_identifier_apar			=	null;
	
//	personal details fields
	String      	  l_empid 			=	null;		//PK
	String			  l_mname			=	null; 				
	String 			  l_fathername		=   null;
	String 		 	  l_mothername		=   null;
	String 			  l_dob				=   null;		//date
	String			  l_pan				=	null;
	String 			  l_peraddress		=   null;			//----used
	String 			  l_landline		=   null;
	String 			  l_mobile			=   null;
	String 			  l_personalemail   =   null;
	String 			  l_martial			=   null;
	String 			  l_marriage		=   null;		//date
	String 			  l_dependents		=	null;
	String 			  l_spouse 			=   null;
	String 			  l_religion		=   null;
	String 			  l_bloodgroup		=   null;

// permanent address fields-----------------------------
	String			  l_per_houseno		=	null;
	String			  l_per_street		=	null;
	String			  l_per_city		=	null;
	String			  l_per_state		=	null;
	String			  l_per_country		=	null;
	String			  l_per_pincode		=	null;
//	-------------------------------------------------------

// correspondence address fields
	String 			  l_addressid		= null; 	//PK
	String 			  l_houseno 		= null;
	String 		      l_street 			= null;
	String 			  l_city 			= null;
	String 			  l_state 			= null;
	String			  l_country 		= null;
	String			  l_pincode 		= null;
// employment fields
	String 			  l_employmentid	= null;		//PK
	String 			  l_appointment		= null;		//date
	String 			  l_confirmation	= null;		//date
	String			  l_probation		= null;
	String 			  l_resignation		= null;		//date
	String 			  l_branch			= null;
	String 			  l_designation		= null;
	String 			  l_dept			= null;
	String 			  l_grade			= null;
	
//experience fields
	String[] 		  l_companyname		= null;
	String[] 		  l_location		= null;
	String[] 		  l_expdesign		= null;
	String[]		  l_from			= null;		//date
	String[]		  l_to				= null;		//date
	
//family fields
	String[] 		  l_family_name		= null;
	String[] 		  l_family_address	= null;
	String[]		  l_family_relation	= null;
	String[] 		  l_family_dob		= null;		//date
		
//id proof fields 
	String[] 		  l_id_type			= null;
	String[] 		  l_expiry			= null;			//date
	String[]		  l_number			= null;
	String[] 		  l_link			= null;

//qualification fields		 
	String[] 		  l_qualification	= null;
	String[] 		  l_university		= null;
	String[]	  	  l_year			= null;		//int
	String[] 		  l_percent			= null;		//float
	String[] 		  l_qgrade			= null;

	// nominee fields
	String[] 		 l_nominee_name		= null;
	String[]		 l_nominee_relation	= null;
	String[] 		 l_nominee_address	= null;
	String[] 		 l_nominee_dob		= null;
	String[]		 l_nominee_share	= null;

    public RegisterEmployeeDetailsAdmin() {
        super();
    }

    protected void doPost(HttpServletRequest p_request, HttpServletResponse p_response) throws ServletException, IOException {

		p_response.setContentType("text/html");
		PrintWriter  out 		=	 p_response.getWriter();
		
		l_request_map		=	new HashMap<String, Object>();
		l_enum_parameter	=	p_request.getParameterNames();
	
//  putting values in map from jsp page		
		while(l_enum_parameter.hasMoreElements())
		{
			String parameterName	=  l_enum_parameter.nextElement();
			String parameterValue	=  p_request.getParameter(parameterName);
			l_request_map.put(parameterName, parameterValue);
		}
		
//	fetching address fields to concat and make permanent address
			l_per_houseno	=	 p_request.getParameter("houseno1");
			l_per_street	=	 p_request.getParameter("street1");
			l_per_city		=	 p_request.getParameter("city1");	
			l_per_state		=	 p_request.getParameter("state1");
			l_per_country	=	 p_request.getParameter("country1");
			l_per_pincode	=	 p_request.getParameter("pincode1");
			l_peraddress	=	 l_per_houseno+","+l_per_street+","+l_per_city+","+l_per_state+","+l_per_country+","+l_per_pincode;
			
			l_request_map.put("permanent_address", l_peraddress);

//	checking for null values in the text box
		l_mname 		= CommonFunction.convertNullValues((String) l_request_map.get("middleName"));
		l_marriage 		= CommonFunction.convertNullValues((String) l_request_map.get("mdate"));
		l_spouse 		= CommonFunction.convertNullValues((String) l_request_map.get("spouse"));

		l_resignation	= CommonFunction.convertNullValues((String) l_request_map.get("earl_resign"));
		l_branch 		= CommonFunction.convertNullValues((String) l_request_map.get("earl_branch"));
		l_designation 	= CommonFunction.convertNullValues((String) l_request_map.get("earl_designation"));
		l_dept 			= CommonFunction.convertNullValues((String) l_request_map.get("earl_dept"));
		l_grade 		= CommonFunction.convertNullValues((String) l_request_map.get("earl_grade"));

		/*l_companyname 	= CommonFunction.convertNullValues((String) l_request_map.get("org_company"));
		l_location 		= CommonFunction.convertNullValues((String) l_request_map.get("org_location"));
		l_expdesign 	= CommonFunction.convertNullValues((String) l_request_map.get("org_designation"));
		l_from			= CommonFunction.convertNullValues((String) l_request_map.get("fromdate"));
		l_to 			= CommonFunction.convertNullValues((String) l_request_map.get("todate"));
*/
	/*  l_nomineename 		= CommonFunction.convertNullValues((String) l_request_map.get("nominee_name"));
		l_nomineeaddress 	= CommonFunction.convertNullValues((String) l_request_map.get("nominee_address"));
		l_nomineerelation 	= CommonFunction.convertNullValues((String) l_request_map.get("nominee_relation"));
		l_nomineedob 		= CommonFunction.convertNullValues((String) l_request_map.get("nominee_dob"));
		l_share 			= CommonFunction.convertNullValues((String) l_request_map.get("nominee_percentage"));*/
			
//	putting values in map after checking for null		
			l_request_map.put("middleName",l_mname);
			l_request_map.put("mdate",l_marriage);
			l_request_map.put("spouse",l_spouse);
			l_request_map.put("earl_resign",l_resignation);
			l_request_map.put("earl_branch",l_branch);
			l_request_map.put("earl_designation",l_designation);
			l_request_map.put("earl_dept",l_dept);
			l_request_map.put("earl_grade",l_grade);
			
			/*
			l_request_map.put("org_company",l_companyname);
			l_request_map.put("org_location",l_location);
			l_request_map.put("org_designation",l_expdesign);
			l_request_map.put("fromdate",l_from);
			l_request_map.put("todate",l_to);
			
			l_request_map.put("nominee_name",l_nomineename);
			l_request_map.put("nominee_address",l_nomineeaddress);
			l_request_map.put("nominee_relation",l_nomineerelation);
			l_request_map.put("nominee_dob",l_nomineedob);
			l_request_map.put("nominee_percentage",l_share);*/
			
					
		/*	for (Map.Entry<String, Object> entry : l_request_map.entrySet()) {
			     System.out.println("Key = " + entry.getKey() + " , Value = " + entry.getValue());
			}
		*/
			
/**
 * 	fetching multiple fields control values and storing them in array
 */
					 l_nominee_name		=	p_request.getParameterValues("nominee_name");
					 l_nominee_relation	=	p_request.getParameterValues("nominee_relation");
					 l_nominee_address	=	p_request.getParameterValues("nominee_address");
					 l_nominee_dob		=	p_request.getParameterValues("nominee_dob");
					 l_nominee_share	=	p_request.getParameterValues("nominee_percentage");

//  qualification fields
					 l_qualification	= p_request.getParameterValues("qualification");
					 l_university		= p_request.getParameterValues("college");
					 l_year				= p_request.getParameterValues("year");		//int
					 l_percent			= p_request.getParameterValues("percentage");		
					 l_qgrade			= p_request.getParameterValues("grade");
			
//	id proof fields
					 l_id_type			=	p_request.getParameterValues("idtype");
					 l_expiry			=	p_request.getParameterValues("expiry");
					 l_number			=	p_request.getParameterValues("idno");
					 l_link				=	p_request.getParameterValues("file");

//	work experience fields		
					 l_companyname		=	p_request.getParameterValues("org_company");	
					 l_location			=	p_request.getParameterValues("org_location");	
					 l_expdesign		=	p_request.getParameterValues("org_designation");
					 l_from				=	p_request.getParameterValues("fromdate");	
					 l_to				=	p_request.getParameterValues("todate");
					 
//	family fields
					 l_family_name		=	p_request.getParameterValues("family_name");
					 l_family_address	=	p_request.getParameterValues("family_address");
					 l_family_relation	=	p_request.getParameterValues("family_relation");
					 l_family_dob		=	p_request.getParameterValues("family_dob");

					 System.out.println("printing id:::"	    +l_request_map.get("empid"));
					 System.out.println("request value id ::: " +p_request.getParameter("empid"));					 
/**
 *  	combining and executing the code
 */
	try{
		conn = ConnectionProvider.getConnection();

		String sql= " UPDATE emp_personal_details  SET  firstname=?, middlename=?, lastname=?, father_name=?, mother_name=?, date_of_birth=?, gender=?, PAN=?, permanent_address=?, landline=?, mobile=?,personal_email=?, martial_status=?, marriage_date=?, no_of_dependents=? , spouse_name=? , religion=?, blood_group=? WHERE emp_id=?";
		
		PreparedStatement ps 	=	(PreparedStatement) conn.prepareStatement(sql);
//		empid is being assigned manually by the admin
		ps.setObject(1,l_request_map.get("firstName") );
		ps.setObject(2,l_request_map.get("middleName") );
		ps.setObject(3,l_request_map.get("lastName") );
		ps.setObject(4,l_request_map.get("father") );
		ps.setObject(5,l_request_map.get("mother") );
		ps.setObject(6,l_request_map.get("dob"));
		ps.setObject(7,l_request_map.get("gender") );
		ps.setObject(8,l_request_map.get("pan") );
		ps.setObject(9,l_peraddress );
		ps.setObject(10,l_request_map.get("landline") );
		ps.setObject(11,l_request_map.get("mobile") );
		ps.setObject(12,l_request_map.get("pemail") );
		ps.setObject(13,l_request_map.get("mstatus") );
		ps.setObject(14,l_request_map.get("mdate") );
		ps.setObject(15,l_request_map.get("depend") );
		ps.setObject(16,l_request_map.get("spouse") );
		ps.setObject(17,l_request_map.get("religion") );
		ps.setObject(18,l_request_map.get("blood"));
		ps.setObject(19,l_request_map.get("empid"));
		ps.executeUpdate();
//	--------------------------------------------------------------------------------------------------------------
		l_identifier_add 		= 	IdGeneratorFactory.generateUniqueId("ADD", null);
		PreparedStatement ps1 	= 	(PreparedStatement) conn.prepareStatement("insert into emp_address(emp_id,id_address,house_number,street,city,state,country,pincode) values(?,?,?,?,?,?,?,?) ");			
		ps1.setObject(1,l_request_map.get("empid") );
		ps1.setObject(2,l_identifier_add );
		ps1.setObject(3,l_request_map.get("houseno2") );
		ps1.setObject(4,l_request_map.get("street2") );
		ps1.setObject(5,l_request_map.get("city2") );
		ps1.setObject(6,l_request_map.get("state2") );
		ps1.setObject(7,l_request_map.get("country2") );
		ps1.setObject(8,l_request_map.get("pincode2") );
		ps1.executeUpdate();
//--------------------------------------------------------------------------------------------------------------		

		for(int i=0;i<l_qualification.length;i++) {
			 String test_year = l_year[i];
			 int q_year = Integer.parseInt(test_year);
			
			 String test_per = l_percent[i];
			 int q_per = Integer.parseInt(test_per);
			 
		l_identifier_qualification = IdGeneratorFactory.generateUniqueId("Q", null);
		PreparedStatement ps2	   = (PreparedStatement) conn.prepareStatement("insert into emp_qualifications(id_qualification,emp_id,qualification,university,year_of_passing,percentage,grade) values(?,?,?,?,?,?,?)");
		
		System.out.println("in qualification::"+i);
		System.out.println(l_grade);
		ps2.setObject(1, l_identifier_qualification);
		ps2.setObject(2, l_request_map.get("empid"));
		ps2.setObject(3, l_qualification[i]);
		ps2.setObject(4, l_university[i]);
		ps2.setObject(5, q_year);
		ps2.setObject(6, q_per);
		ps2.setObject(7, l_qgrade[i]);
		ps2.executeUpdate();
		}
//	--------------------------------------------------------------------------------------------------------------		
		for(int i=0;i<l_id_type.length;i++) {
		l_identifier_proof		=	IdGeneratorFactory.generateUniqueId("P", null);
		PreparedStatement ps3	= (PreparedStatement) conn.prepareStatement("insert into emp_id_proof(proof_id,emp_id,proof_type,expiry_date,proof_number,file_link) values(?,?,?,?,?,?)");
		l_expiry[i]	=	CommonFunction.convertNullValues((String) l_request_map.get("org_designation"));
		System.out.println("in id proof::"+i);
		
		ps3.setObject(1, l_identifier_proof);
		ps3.setObject(2, l_request_map.get("empid"));
		ps3.setObject(3, l_id_type[i]);
		ps3.setObject(4, l_expiry[i]);
		ps3.setObject(5, l_number[i]);
		ps3.setObject(6, l_link[i]);
		ps3.executeUpdate();
		}
//	--------------------------------------------------------------------------------------------------------------
		
		l_identifier_employment	=	IdGeneratorFactory.generateUniqueId("E", null);
		PreparedStatement ps4 	= (PreparedStatement) conn.prepareStatement("UPDATE emp_employment_details  SET id_employment=?,  date_of_appointment=?, confirmation_date=?, probation_period=?,previous_org_resignation_date=?, previous_org_branch=?, previous_org_designation=?, previous_org_department=?, grade=?    WHERE emp_id=?");
	
		ps4.setObject(1, l_identifier_employment);
		ps4.setObject(2, l_request_map.get("appoint"));	
		ps4.setObject(3, l_request_map.get("confirm"));	
		ps4.setObject(4, l_request_map.get("probation"));	
		ps4.setObject(5, l_request_map.get("earl_resign"));	
		ps4.setObject(6, l_request_map.get("earl_branch"));	
		ps4.setObject(7, l_request_map.get("earl_designation"));	
		ps4.setObject(8, l_request_map.get("earl_dept"));	
		ps4.setObject(9, l_request_map.get("earl_grade"));
		ps4.setObject(10, l_request_map.get("empid"));
		ps4.executeUpdate();
		
//	--------------------------------------------------------------------------------------------------------------
		l_identifier_financial	=	IdGeneratorFactory.generateUniqueId("F", null);
		PreparedStatement ps5 	= (PreparedStatement) conn.prepareStatement("insert into emp_financial_details(id_finance,emp_id,bank_name,bank_branch,account_number,ifsc) values(?,?,?,?,?,?)");
		
		ps5.setObject(1, l_identifier_financial);
		ps5.setObject(2, l_request_map.get("empid"));
		ps5.setObject(3, l_request_map.get("bank"));
		ps5.setObject(4, l_request_map.get("branch"));
		ps5.setObject(5, l_request_map.get("account"));
		ps5.setObject(6, l_request_map.get("ifsc"));
		ps5.executeUpdate();
//	--------------------------------------------------------------------------------------------------------------
		
		for(int i=0;i<l_companyname.length;i++) {
			
		l_identifier_experience	=	IdGeneratorFactory.generateUniqueId("D", null);
		PreparedStatement ps6 	= (PreparedStatement) conn.prepareStatement("insert into emp_work_experience(id_experience,emp_id,company_name,location,designation,from_date,to_date) values(?,?,?,?,?,?,?) ");
		
		System.out.println("in work experience::"+i);
		
		ps6.setObject(1, l_identifier_experience);
		ps6.setObject(2, l_request_map.get("empid"));
		ps6.setObject(3, l_companyname[i]);
		ps6.setObject(4, l_location[i]);
		ps6.setObject(5, l_expdesign[i]);
		ps6.setObject(6, l_from[i]);
		ps6.setObject(7, l_to[i]);
		ps6.executeUpdate();
		}
//	--------------------------------------------------------------------------------------------------------------
		for(int i=0;i<l_family_name.length;i++) {
		l_identifier_family	=	IdGeneratorFactory.generateUniqueId("F", null);
		PreparedStatement ps7 = (PreparedStatement) conn.prepareStatement("insert into emp_family_details(id_family,emp_id,name,address,relationship,dob) values(?,?,?,?,?,?) ");
		
		System.out.println("in family::"+i);
		
		ps7.setObject(1, l_identifier_family);
		ps7.setObject(2, l_request_map.get("empid"));
		ps7.setObject(3, l_family_name[i]);
		ps7.setObject(4, l_family_address[i]);
		ps7.setObject(5, l_family_relation[i]);
		ps7.setObject(6, l_family_dob[i]);  
		ps7.executeUpdate();
		}
//	--------------------------------------------------------------------------------------------------------------
		for(int i=0;i<l_nominee_name.length;i++) {
			System.out.println("in nominee::"+i);	
		
		l_identifier_nominee	=	IdGeneratorFactory.generateUniqueId("N", null);
		PreparedStatement ps8 	= 	(PreparedStatement) conn.prepareStatement("insert into emp_nominee(id_nominee,emp_id,name,address,relationship,dob,share_percent) values(?,?,?,?,?,?,?)");
		ps8.setObject(1,l_identifier_nominee );
		ps8.setObject(2,l_request_map.get("empid") );
		ps8.setObject(3,l_nominee_name[i] );
		ps8.setObject(4,l_nominee_address[i] );
		ps8.setObject(5,l_nominee_relation [i]);
		ps8.setObject(6,l_nominee_dob[i]);
		ps8.setObject(7,l_nominee_share[i] );
		ps8.executeUpdate();
		}
		
//	--------------------------------------------------------------------------------------------------------------
		
		/**
		 * This insert statements ensure that whenever a new employee is registered,
		 * an entry in the emp_leave_details table is inserted for default values for an employee's leave.	
		 */
			l_identifier_leave		=	IdGeneratorFactory.generateUniqueId("L", null);
			PreparedStatement ps10 	= 	(PreparedStatement) conn.prepareStatement("insert into emp_leave_details values(?,?,?,?,?)");
			ps10.setObject(1, l_identifier_leave );
			ps10.setObject(2, 15 );
			ps10.setObject(3, 10);
			ps10.setObject(4, 5);
			ps10.setObject(5,l_request_map.get("empid"));
			ps10.executeUpdate();
//	--------------------------------------------------------------------------------------------------------------
			/**
			 * Administrator specific functions
			 */
			
			l_identifier_apar	=	IdGeneratorFactory.generateUniqueId("C", null);
			PreparedStatement ps9 	= 	(PreparedStatement) conn.prepareStatement("	UPDATE emp_apar_details SET id_company=?, payroll_id=?, position=?, department=?, company_email=?, salary=?, status=?, reporting_manager=?, emp_type=?  WHERE emp_id=?");
			
			ps9.setObject(1,l_identifier_apar);
			ps9.setObject(2, l_request_map.get("payroll"));			
			ps9.setObject(3, l_request_map.get("position"));
			ps9.setObject(4, l_request_map.get("dept"));
			ps9.setObject(5, l_request_map.get("cemail"));
			ps9.setObject(6, l_request_map.get("salary"));
			ps9.setObject(7, l_request_map.get("status"));
			ps9.setObject(8, l_request_map.get("manager"));
			ps9.setObject(9, l_request_map.get("etype"));
			ps9.setObject(10, l_request_map.get("empid"));
			ps9.executeUpdate();
//	-------------------------------------------------------------------------------
			
			/**
			 *  	This block of code fetches the multiple values that are selected in the checkbox and stores them in 
			 *  	their respective tables. 
			 *  	performed by Administrator only
			 */
			
			String roles[] = p_request.getParameterValues("role");
			for (int i = 0; i < roles.length; i++) {
				String sql_role = "select id_role from emp_role where role='" + roles[i] + "'";
				Statement statement = (Statement) conn.createStatement();
				ResultSet rs = statement.executeQuery(sql_role);
				String l_identifier_role = IdGeneratorFactory.generateUniqueId("ER", null);
				PreparedStatement ps11 = (PreparedStatement) conn.prepareStatement("insert into user_role_map values(?,?,?)");
				
				while (rs.next()) {
					ps11.setObject(1, rs.getString(1));
					ps11.setObject(2, l_request_map.get("empid"));
					ps11.setObject(3, l_identifier_role);

					ps11.executeUpdate();
				}
			}
		
		p_response.sendRedirect("profileAdmin.jsp");		
		}
	catch(Exception e)
		{
			out.println(e.getMessage());
		}
		finally {
					DbUtil.close(conn);
					
				}	

    }

}
