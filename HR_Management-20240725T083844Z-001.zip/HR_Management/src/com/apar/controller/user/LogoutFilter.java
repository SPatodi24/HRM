/**
 * This class is used to check for existing session if the user 
 * clicks the back button on the address bar of the browser.
 * It prevents the user from going back if session has expired.
 */

package com.apar.controller.user;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LogoutFilter {

	HttpServletRequest  l_request	= 	null;
	HttpServletResponse l_response	=	null;
	
	public void filter() {
		
		HttpSession session = l_request.getSession();
		if(session == null || session.getAttribute("id") == null) {}
//			 l_response.sendRedirect("login.jsp");
			
		
	}
}
