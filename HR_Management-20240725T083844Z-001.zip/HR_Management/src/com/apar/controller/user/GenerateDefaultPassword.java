/**
 * This class generated a random password for the user and updated it to the database.
 * @see UpdateDbForgotPassword
 */
package com.apar.controller.user;
import java.util.*;
import java.math.*;
import java.util.Random;

public class GenerateDefaultPassword {
	public static String defaultPassword() {
		Random rand	=	new Random();
		char[] values1 = { 'w', 'e', 'c', 's', 'p', 'a', 'm', 'S', 'M', 'A', 'H', 'E', 'V' ,'k','B'};
		char[] values2 = { '@', '$', '#' };
		char[] values3 = { '1', '2', '3', '4', '5', '6', '7', '8', '9', '0' };
		String out1 = "";
		String out2 = "";
		String out3 = "";
		String out	=	null;

		for (int i = 0; i < 6; i++) {
			int idx = rand.nextInt(values1.length);
			out1 += values1[idx];
		}

		for (int i = 0; i < 3; i++) {
			int idx = rand.nextInt(values3.length);
			out2 += values3[idx];
		}

		for (int i = 0; i < 1; i++) {
			int idx = rand.nextInt(values2.length);
			out3 += values2[idx];
		}

		out = out1.concat(out3).concat(out2);
		
		return out;
	}
	
}
