/**
 * This servlet updates the database with the new password that is generated randomly.
 * @see GenerateDefaultPassword
 */
package com.apar.controller.user;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.mysql.jdbc.PreparedStatement;

import com.apar.dbconnection.ConnectionProvider;
import com.apar.dbconnection.DbUtil;

//@WebServlet("/UpdateDbForgotPassword")
public class UpdateDbForgotPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private	Connection  conn	  =	null;
	private Statement 	statement = null;
	private ResultSet 	resultSet = null;
	
			String 		l_emp		  = null;
			String 	 	l_email	  	  =	null;
			String 	 	l_password	  =	null;
	
	
    public UpdateDbForgotPassword() {
        super();
     
    }

	public  void fetchEmail(String p_email,String p_password)
	{
		l_email 	= 	p_email;
		l_password	=	p_password;
		System.out.println("the email & password from forgotMail class::::"+l_email+"   "+l_password);
		
		try{
			conn 		= ConnectionProvider.getConnection();
			statement	= conn.createStatement();
			String sql = "select * from emp_apar_details where company_email = '" + p_email+"'";    
				
			resultSet = statement.executeQuery(sql);
			while(resultSet.next()){
					l_emp	=	resultSet.getString(2);
			}
			System.out.println("fetching emp id from db :::::"+l_emp);
			
			String updatesql		=   "update emp_login set password=? where login_id=? "	;
			PreparedStatement ps 	=	(PreparedStatement) conn.prepareStatement(updatesql);
			ps.setString(1, l_password);
			ps.setString(2, l_emp);
			ps.executeUpdate();
			
			System.out.println("user updated with new password!!");
		}
		catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			finally {
						DbUtil.close(conn);
					}
		
	}
	/*protected void doPost(HttpServletRequest p_request, HttpServletResponse p_response,String p_email,String p_password) throws ServletException, IOException {
		
		p_response.setContentType("text/html");
		PrintWriter  out 		=	 p_response.getWriter();
	
		
		
		
	}*/
	

}
