package com.apar.controller.user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.apar.common.IdGeneratorFactory;
import com.apar.dbconnection.ConnectionProvider;
import com.apar.dbconnection.DbUtil;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;


//@WebServlet("/AddAparDetails")
public class AddAparDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private	Connection        conn			=	null;
	
	Map <String, Object> l_request_map		=	null;
	Enumeration<String>  l_enum_parameter	=	null;   
	String l_identifier_apar			=	null;
	String roles[] 	=	null;
    public AddAparDetails() {
        super();
   }

	protected void doPost(HttpServletRequest p_request, HttpServletResponse p_response) throws ServletException, IOException {
		
		p_response.setContentType("text/html");
		PrintWriter  out 		=	 p_response.getWriter();
		
		l_request_map		=	new HashMap<String, Object>();
		l_enum_parameter	=	p_request.getParameterNames();
	
//  putting values in map from jsp page		
		while(l_enum_parameter.hasMoreElements())
		{
			String parameterName	=  l_enum_parameter.nextElement();
			String parameterValue	=  p_request.getParameter(parameterName);
			l_request_map.put(parameterName, parameterValue);
		}
		System.out.println(l_request_map.get("empid"));
		System.out.println(p_request.getParameter("empid"));
		
		try
		{
			conn = ConnectionProvider.getConnection();
			l_identifier_apar	=	IdGeneratorFactory.generateUniqueId("C", null);
			PreparedStatement ps9 	= 	(PreparedStatement) conn.prepareStatement(
				"UPDATE emp_apar_details SET id_company=?, payroll_id=?, position=?, department=?, company_email=?, salary=?, status=?, reporting_manager=?, emp_type=?  WHERE emp_id=?");
			
			ps9.setObject(1,l_identifier_apar);
			ps9.setObject(2, l_request_map.get("payroll"));			
			ps9.setObject(3, l_request_map.get("position"));
			ps9.setObject(4, l_request_map.get("dept"));
			ps9.setObject(5, l_request_map.get("cemail"));
			ps9.setObject(6, l_request_map.get("salary"));
			ps9.setObject(7, l_request_map.get("status"));
			ps9.setObject(8, l_request_map.get("manager"));
			ps9.setObject(9, l_request_map.get("etype"));
			ps9.setObject(10, l_request_map.get("empid"));
			ps9.executeUpdate();
//			p_response.sendRedirect("searchemployee.jsp");
//		-------------------------------------------------------------------------------
			roles	= p_request.getParameterValues("role");
			//while (rs.next()) {
			for (int i = 0; i < roles.length; i++) {
				//String sql_role = "select id_role from emp_role where role='" + roles[i] + "'";
				//Statement statement = (Statement) conn.createStatement();
				//ResultSet rs = statement.executeQuery(sql_role);
				String l_identifier_role = IdGeneratorFactory.generateUniqueId("ER", null);
//					PreparedStatement ps11 = (PreparedStatement) conn.prepareStatement("insert into user_role_map values(?,?,?)");
				PreparedStatement ps11 = (PreparedStatement) conn.prepareStatement("insert into user_role_map values(?,?,?)");
					ps11.setObject(1, roles[i]);
					ps11.setObject(2, l_request_map.get("empid"));
					ps11.setObject(3, l_identifier_role);
					ps11.executeUpdate();
				//}
			
			}
			System.out.println("details updated");
			
//		-------------------------------------------------------------------------------
			
			p_response.sendRedirect("searchemployee.jsp");

		}catch(Exception e)
		{
			out.println(e.getMessage());
		}
		finally {
					DbUtil.close(conn);
					
				}	
		
	}

}
