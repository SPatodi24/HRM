/**
 * This bean class contains fields of table emp_family_details.
 */
package com.apar.beans;

import java.util.Date;

public class EmployeeFamily {

//  private String emp_id; 			    //foreign key
	private String familyid;			//PK
	private String familyname;
	private String familyaddress;
	private String familyrelation;
	private Date familydob;

	public String getFamilyid() {
		return familyid;
	}

	public void setFamilyid(String familyid) {
		this.familyid = familyid;
	}

	public String getFamilyname() {
		return familyname;
	}

	public void setFamilyname(String familyname) {
		this.familyname = familyname;
	}

	public String getFamilyaddress() {
		return familyaddress;
	}

	public void setFamilyaddress(String familyaddress) {
		this.familyaddress = familyaddress;
	}

	public String getFamilyrelation() {
		return familyrelation;
	}

	public void setFamilyrelation(String familyrelation) {
		this.familyrelation = familyrelation;
	}

	public Date getFamilydob() {
		return familydob;
	}

	public void setFamilydob(Date familydob) {
		this.familydob = familydob;
	}

}
