/**
 * This bean class contains fields of table emp_login.
 */
package com.apar.beans;

public class EmployeeLogin {
	
	private int no; 				// PK
//	private String loginid; 		// FK
	private String pass;
	

	/*public String getLoginid() {
		return loginid;
	}

	public void setLoginid(String loginid) {
		this.loginid = loginid;
	}*/

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

}
