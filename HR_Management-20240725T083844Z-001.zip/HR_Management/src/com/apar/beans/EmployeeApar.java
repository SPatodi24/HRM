/**
 * This bean class contains fields of table emp_apar_details.
 * These fields can only be accessed or manipulated by the administrator.
 */
package com.apar.beans;

public class EmployeeApar {
//	private String emp_id; 				//foreign key
	private String companyid; 			// primary key
	private String payrollid;
	private String position;
	private String department;
	private String companyemail;
	private String salary;
	private String status;
	private String manager;
	private String type;

	public String getCompanyid() {
		return companyid;
	}

	public void setCompanyid(String companyid) {
		this.companyid = companyid;
	}

	public String getPayrollid() {
		return payrollid;
	}

	public void setPayrollid(String payrollid) {
		this.payrollid = payrollid;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getCompanyemail() {
		return companyemail;
	}

	public void setCompanyemail(String companyemail) {
		this.companyemail = companyemail;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
