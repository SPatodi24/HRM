/**
 * This bean class contains fields of table emp_financial_details.
 */
package com.apar.beans;

public class EmployeeFinancial {

//	private String emp_id; 			    //foreign key
	private String financeid;			//PK
	private String bank;
	private String bankbranch;
	private String accountno;
	private String ifsc;

	public String getFinanceid() {
		return financeid;
	}

	public void setFinanceid(String financeid) {
		this.financeid = financeid;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public String getBankbranch() {
		return bankbranch;
	}

	public void setBankbranch(String branch) {
		this.bankbranch = branch;
	}

	public String getAccountno() {
		return accountno;
	}

	public void setAccountno(String accountno) {
		this.accountno = accountno;
	}

	public String getIfsc() {
		return ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
}
