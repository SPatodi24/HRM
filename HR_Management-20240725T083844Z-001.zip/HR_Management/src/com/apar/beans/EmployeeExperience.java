/**
 * This bean class contains fields of table emp_work_experience.
 */
package com.apar.beans;

import java.util.Date;

public class EmployeeExperience {
	
//	private String emp_id; 			    //foreign key
	private String experienceid;			//PK
	private String companyname;
	private String location;
	private String expdesign;
	private Date from;
	private Date to;

	public String getExperienceid() {
		return experienceid;
	}

	public void setExperienceid(String experienceid) {
		this.experienceid = experienceid;
	}

	public String getCompanyname() {
		return companyname;
	}

	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getExpdesign() {
		return expdesign;
	}

	public void setExpdesign(String expdesign) {
		this.expdesign = expdesign;
	}

	public Date getFrom() {
		return from;
	}

	public void setFrom(Date from) {
		this.from = from;
	}

	public Date getTo() {
		return to;
	}

	public void setTo(Date to) {
		this.to = to;
	}

}
