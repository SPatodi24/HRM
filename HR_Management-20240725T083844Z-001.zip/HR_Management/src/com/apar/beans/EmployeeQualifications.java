/**
 * This bean class contains fields of table emp_qualifications.
 */
package com.apar.beans;

public class EmployeeQualifications {

//	private String emp_id; 			    //foreign key
	private String qualificationid;
	private String qualification;
	private String university;
	private int year;
	private float percent;
	private String qgrade;
	
	public String getQualificationid() {
		return qualificationid;
	}
	public void setQualificationid(String qualificationid) {
		this.qualificationid = qualificationid;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getUniversity() {
		return university;
	}
	public void setUniversity(String university) {
		this.university = university;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public float getPercent() {
		return percent;
	}
	public void setPercent(float percent) {
		this.percent = percent;
	}
	public String getQgrade() {
		return qgrade;
	}
	public void setQgrade(String qgrade) {
		this.qgrade = qgrade;
	}
	
}
