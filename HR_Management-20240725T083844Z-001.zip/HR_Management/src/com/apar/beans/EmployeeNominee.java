/**
 * This bean class contains fields of table emp_nominee.
 */
package com.apar.beans;

import java.util.Date;

public class EmployeeNominee {

//	private String emp_id;				 //foreign key
	private String nomineeid;			 //PK
	private String nomineename;
	private String nomineeaddress;
	private String nomineerelation;
	private Date nomineedob;

	public String getNomineeid() {
		return nomineeid;
	}

	public void setNomineeid(String nomineeid) {
		this.nomineeid = nomineeid;
	}

	public String getNomineename() {
		return nomineename;
	}

	public void setNomineename(String nomineename) {
		this.nomineename = nomineename;
	}

	public String getNomineeaddress() {
		return nomineeaddress;
	}

	public void setNomineeaddress(String nomineeaddress) {
		this.nomineeaddress = nomineeaddress;
	}

	public String getNomineerelation() {
		return nomineerelation;
	}

	public void setNomineerelation(String nomineerelation) {
		this.nomineerelation = nomineerelation;
	}

	public Date getNomineedob() {
		return nomineedob;
	}

	public void setNomineedob(Date nomineedob) {
		this.nomineedob = nomineedob;
	}

	public float getShare() {
		return share;
	}

	public void setShare(float share) {
		this.share = share;
	}

	private float share;
}
