/**
 * This bean class contains fields of table emp_employment_details.
 */

package com.apar.beans;

import java.util.Date;

public class EmployeeEmployement {
	
//	private String emp_id; 			    //foreign key
	private String employmentid;
	private Date appointment;
	private Date confirmation;
	private int probation;
	private Date resignation;
	private String branch;
	private String designation;
	private String dept;
	private String grade;

	public String getEmploymentid() {
		return employmentid;
	}

	public void setEmploymentid(String employmentid) {
		this.employmentid = employmentid;
	}

	public Date getAppointment() {
		return appointment;
	}

	public void setAppointment(Date appointment) {
		this.appointment = appointment;
	}

	public Date getConfirmation() {
		return confirmation;
	}

	public void setConfirmation(Date confirmation) {
		this.confirmation = confirmation;
	}

	public int getProbation() {
		return probation;
	}

	public void setProbation(int probation) {
		this.probation = probation;
	}

	public Date getResignation() {
		return resignation;
	}

	public void setResignation(Date resignation) {
		this.resignation = resignation;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

}
