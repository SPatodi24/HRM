/**
 * This bean class contains fields of table emp_personal_details.
 */
package com.apar.beans;

import java.util.Date;

public class EmployeePersonal {
	private String empid;			//primary key
	private String fname;
	private String mname;
	private String lname;
	private String fathername;
	private String mothername;
	private Date   dob;
	private String gender;
	private String peraddress;
	private String landline;
	private String mobile;
	private String personalemail;
	private String martial;
	private Date   marriage;
	private int    dependents;
	private String spouse;
	private String religion;
	private String bloodgroup;

	public String getEmpid() {
		return empid;
	}

	public void setEmpid(String empid) {
		this.empid = empid;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getFathername() {
		return fathername;
	}

	public void setFathername(String fathername) {
		this.fathername = fathername;
	}

	public String getMothername() {
		return mothername;
	}

	public void setMothername(String mothername) {
		this.mothername = mothername;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPeraddress() {
		return peraddress;
	}

	public void setPeraddress(String peraddress) {
		this.peraddress = peraddress;
	}

	public String getLandline() {
		return landline;
	}

	public void setLandline(String landline) {
		this.landline = landline;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getPersonalemail() {
		return personalemail;
	}

	public void setPersonalemail(String personalemail) {
		this.personalemail = personalemail;
	}

	public String getMartial() {
		return martial;
	}

	public void setMartial(String martial) {
		this.martial = martial;
	}

	public Date getMarriage() {
		return marriage;
	}

	public void setMarriage(Date marriage) {
		this.marriage = marriage;
	}

	public int getDependents() {
		return dependents;
	}

	public void setDependents(int dependents) {
		this.dependents = dependents;
	}

	public String getSpouse() {
		return spouse;
	}

	public void setSpouse(String spouse) {
		this.spouse = spouse;
	}

	public String getReligion() {
		return religion;
	}

	public void setReligion(String religion) {
		this.religion = religion;
	}

	public String getBloodgroup() {
		return bloodgroup;
	}

	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}
}
