/**
 * This bean class contains fields of table emp_leave_details.
 */
package com.apar.beans;

public class EmployeeLeave {
	
//  private String emp_id; 			    //foreign key
	private String leavesid;
	private int earned;
	private int sick;
	private int casual;
	private int other;

	public String getLeavesid() {
		return leavesid;
	}

	public void setLeavesid(String leavesid) {
		this.leavesid = leavesid;
	}

	public int getEarned() {
		return earned;
	}

	public void setEarned(int earned) {
		this.earned = earned;
	}

	public int getSick() {
		return sick;
	}

	public void setSick(int sick) {
		this.sick = sick;
	}

	public int getCasual() {
		return casual;
	}

	public void setCasual(int casual) {
		this.casual = casual;
	}

	public int getOther() {
		return other;
	}

	public void setOther(int other) {
		this.other = other;
	}

}
