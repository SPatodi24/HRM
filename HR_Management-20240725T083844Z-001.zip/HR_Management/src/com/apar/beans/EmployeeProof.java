/**
 * This bean class contains fields of table emp_id_proof.
 */
package com.apar.beans;

import java.util.Date;

public class EmployeeProof {
	
//  private String emp_id; 			    //foreign key
	private String proofid; // PK
	private String type;
	private Date expiry;
	private String number;
	private String link;

	public String getProofid() {
		return proofid;
	}

	public void setProofid(String proofid) {
		this.proofid = proofid;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Date getExpiry() {
		return expiry;
	}

	public void setExpiry(Date expiry) {
		this.expiry = expiry;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

}
