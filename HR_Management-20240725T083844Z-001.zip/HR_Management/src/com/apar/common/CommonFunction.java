package com.apar.common;

public class CommonFunction {
	/**
	 * This method <code>convertNullValueToBlank</code> checks the value of
	 * variable for null case if it is null then convert it into blank.
	 * 
	 * @param p_value
	 *        String value
	 * 
	 * @return p_value 
	 * 		   String value
	 */
	public static String convertNullValues(String p_value) {

		if (p_value.equalsIgnoreCase(" ") || p_value.equalsIgnoreCase("")) {
				p_value = null;
		}

		return p_value;
	}
}
