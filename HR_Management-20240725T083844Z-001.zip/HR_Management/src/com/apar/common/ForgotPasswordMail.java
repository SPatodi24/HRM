/**
 *  this class is used to fetch the email from the jsp page,
 *  setup message structure and then call the method to send the mail.
 *  
 *  @see SendMailSSL
 *  @see forgotpassword.jsp
 */
package com.apar.common;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.apar.dbconnection.ConnectionProvider;
import com.apar.dbconnection.DbUtil;
import com.apar.controller.user.GenerateDefaultPassword;
import com.apar.controller.user.UpdateDbForgotPassword;

public class ForgotPasswordMail extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private	Connection        conn			=	null;
	String					  l_from		=   "sakshi.misc22@gmail.com";
	String					  l_password	=	"testing123";
	String 			 		  l_to			=	null;
	String					  l_msg			=	null;
	String					  l_subject		=	null;
	private static String 	  l_default_pass=	null;
	Map <String, Object> l_request_map		=	null;
	Enumeration<String>  l_enum_parameter	=	null;
	
	UpdateDbForgotPassword	db	=	new UpdateDbForgotPassword();
		 
    public ForgotPasswordMail() {
        super();
    }

    protected void doPost(HttpServletRequest p_request, HttpServletResponse p_response) throws ServletException, IOException {

		p_response.setContentType("text/html");
		PrintWriter out = p_response.getWriter();

		l_request_map = new HashMap<String, Object>();
		l_enum_parameter = p_request.getParameterNames();

		while (l_enum_parameter.hasMoreElements()) {
			String parameterName = l_enum_parameter.nextElement();
			String parameterValue = p_request.getParameter(parameterName).trim();
			l_request_map.put(parameterName, parameterValue);
		}
		
						
		try {
			conn = ConnectionProvider.getConnection();
			// System.out.println(l_request_map.get("forgot"));
			l_to = (String) l_request_map.get("forgot");
			l_default_pass = GenerateDefaultPassword.defaultPassword();

			/**
			 * sending the email and the default password to
			 * UpdateDbForgotPassword class to update database.
			 */
			
			
			db.fetchEmail(l_to, l_default_pass);

			
			
			
			/**
			 * Message structure for mail
			 */

			l_subject = "Apar Technologies Password Reset";

			l_msg = "Hello!" + "\n \n" + "You can sign into your account using a default password : " + l_default_pass
					+ " \n\n\n\nThanks!";
					// ***** Mailer.send((String) to);

			 SendMailSSL.send(l_from,l_password,l_to,l_subject,l_msg);
			 p_response.sendRedirect("login.jsp?success=1");
		} catch (Exception e) {
			out.println(e.getMessage());
		} finally {
			DbUtil.close(conn);
			out.close();
		}
	}

}
