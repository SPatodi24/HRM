package com.apar.common;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

import com.apar.dbconnection.ConnectionProvider;
import com.apar.dbconnection.DbUtil;


/**
 * Servlet implementation class ChangePassword
 */
//@WebServlet("/ChangePassword")
public class ChangePassword extends HttpServlet {
	
	private static final long serialVersionUID  = 1L;
	
//to match password in present in database
	String l_dbpass	=	null;		
	
	private Connection conn			=	null;
	private ResultSet  rs 			=   null;					
	private Statement  st			=	null;
	
	Map <String, Object> l_request_map_pass			=	null;
	Enumeration<String>  l_enum_parameter			=	null;
	
	public ChangePassword() {
        super();
    
    }

	protected void doPost(HttpServletRequest p_request, HttpServletResponse p_response) throws ServletException, IOException {
		p_response.setContentType("text/html");
		PrintWriter  out 		=	 p_response.getWriter();
		
		HttpSession session=p_request.getSession();
		String l_str=(String) session.getAttribute( "id" );
//		System.out.println(l_str);
		
		l_request_map_pass		=	new HashMap<String, Object>();
		l_enum_parameter		=	p_request.getParameterNames();

	/*******************************fetching jsp page values in map ***************/
		while(l_enum_parameter.hasMoreElements())
		{
			String parameterName	=  l_enum_parameter.nextElement();
			String parameterValue	=  p_request.getParameter(parameterName);
			l_request_map_pass.put(parameterName, parameterValue);
		}
	
	/*******************************change password checks****************************/

		try {
			conn = ConnectionProvider.getConnection();
            st	=	(Statement) conn.createStatement();
//  extract old password from DB to match
           if(l_str!=null){
            rs 	=	st.executeQuery("select password from emp_login where login_id ="+l_str);  
            
			while(rs.next())
			{
				l_dbpass=rs.getString(1);
			}
			
			if(l_dbpass.equals(l_request_map_pass.get("oldpass")))
			{
//	if old password is equal to new password, update db
				if(l_request_map_pass.get("newpass").equals(l_request_map_pass.get("confirmpass")))
				{
					PreparedStatement ps= (PreparedStatement) conn.prepareStatement("update emp_login set password=? where login_id=?");
					ps.setObject(1,l_request_map_pass.get("confirmpass"));
					ps.setObject(2,l_str);
					ps.executeUpdate();
					p_response.sendRedirect("login.jsp?success=1");
				}
				else
				{
//					error message.. password does not match.. try again ... new!=confirm
					System.out.println("new != confirm");
					System.out.println(l_request_map_pass.get("newpass")+"::::new pass");
					System.out.println(l_request_map_pass.get("confirmpass")+"::::confirm pass");
				}
			}
			else
			{
//				 old password is incorrect. try again.
				System.out.println("old password is not same.");
				System.out.println(l_request_map_pass.get("newpass")+"::::new pass");
				System.out.println(l_request_map_pass.get("confirmpass")+"::::confirm pass");
			}
			
           }
           
           else
           {
        	   p_response.sendRedirect("login.jsp?error=1");
           }
		} catch (SQLException  e) {
			out.println(e.getMessage());
		}
		finally {
            DbUtil.close(rs);
            DbUtil.close(st);
            DbUtil.close(conn);
        }
		
	}

}
