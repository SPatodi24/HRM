/**
 * This class is used to generate database Id sequences for primary keys.
 */

package com.apar.common;

import java.math.BigInteger;
import java.sql.CallableStatement;
import java.sql.Connection;

import com.apar.dbconnection.ConnectionProvider;

public class IdGeneratorFactory {

	 public static String generateUniqueId(String p_prefix,String p_suffix) throws Exception {
		  if(p_prefix == null) {
		   p_prefix = "default_";
		  }
		  
		  if(p_suffix == null) {
		   p_suffix = "";
		  }
		  
		  return p_prefix+generateId()+p_suffix;
		 }
		 
		 
		 private static synchronized BigInteger generateId() throws Exception {
		  String l_query = "{ call Prod_session_sequence(?) }";
		 
		  Connection conn = ConnectionProvider.getConnection();
			
		  CallableStatement proc_stmt = conn.prepareCall(l_query);
		  
		  proc_stmt.registerOutParameter(1, 0);
		  proc_stmt.execute();
		  String identifier  = proc_stmt.getString(1);
		  
		  BigInteger bi = new BigInteger(identifier, 16);
		  return bi;
		 }
		 
		}