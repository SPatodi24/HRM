
/**
 * This class checks for balance leaves for an employee and if there are balance leaves,
 * it deducts from them and sends a leave request to the manager.
 * @see leaverequestAdmin.jsp
 */
package com.apar.common;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.apar.dbconnection.ConnectionProvider;
import com.apar.dbconnection.DbUtil;
import com.mysql.jdbc.PreparedStatement;

//@WebServlet("/LeaveRequestAdmin")
public class LeaveRequestAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private Connection conn			=	null;
	Statement	l_stm		=	null;
	ResultSet 	l_rst		=	null;
	String		msg			=	null;
	String 		sql			=	null;
	int			value	=	0;
	int			EL		=	0;
	int			SL		=	0;
	int 		CL		=	0;
	
	Map <String, Object> l_leave_map		=	null;
	Enumeration<String>  l_enum_parameter	=	null;

	public LeaveRequestAdmin() {
		super();

	}

	protected void doPost(HttpServletRequest p_request, HttpServletResponse p_response) throws ServletException, IOException {
		p_response.setContentType("text/html");
		PrintWriter  out 		=	 p_response.getWriter();
		
		l_leave_map				=	new HashMap<String, Object>();
		l_enum_parameter		=	p_request.getParameterNames();

/*******************************fetching jsp page values in map ***************/
		while(l_enum_parameter.hasMoreElements())
		{
			String parameterName	=  l_enum_parameter.nextElement();
			String parameterValue	=  p_request.getParameter(parameterName);
			l_leave_map.put(parameterName, parameterValue);
		}
	
		try {
			conn = ConnectionProvider.getConnection();
			l_stm	=	conn.createStatement();
/**
* 	checking if employee has remaining leave. if yes, request for leave is sent to manager.
* 	if not, leave request is rejected by the system.
*/		
			
			String l_sql	=	"select * from emp_leave_details where emp_id="+l_leave_map.get("empid");
			l_rst	=	l_stm.executeQuery(l_sql);
			while(l_rst.next())
			{
				EL	=	l_rst.getInt(2);
				SL	=	l_rst.getInt(3);
				CL	=	l_rst.getInt(4);
			}
			
			
			if(EL	==	0 &&	SL	==	0 &&	CL	==	0)
			{
					msg	= "You have consumed all your leaves.No more leaves allowed";
					System.out.println("in if case:: leave not allowed");
					p_response.sendRedirect("viewLeaveDetailsAdmin.jsp?msg");				//--ASK:how to send the msg to servlet & display------
			}
		
/**
 *  	If employee has leaves, then a query is run that updates db with the employee's leave request.
 */
			else{
			
			String l_identifier = IdGeneratorFactory.generateUniqueId("R", null);
			
			String sql="INSERT INTO emp_leave_request(id_request, emp_id, project_id, leave_type, start, end, reason, status) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement ps = (PreparedStatement) conn.prepareStatement(sql);
			
            ps.setString(1, l_identifier);
    		ps.setObject(2, l_leave_map.get("empid"));
    		ps.setObject(3, l_leave_map.get("projectid"));
    		ps.setObject(4, l_leave_map.get("leave_type"));
    		ps.setObject(5, l_leave_map.get("start"));
    		ps.setObject(6, l_leave_map.get("end"));
    		ps.setObject(7, l_leave_map.get("leave_reason"));
    		ps.setObject(8,"pending");
    		ps.executeUpdate();
    		p_response.sendRedirect("viewLeaveDetailsAdmin.jsp?success=1");
    		
		}}
		catch(Exception e){
			System.out.println("error:"+e.getMessage());
		}
		
		finally {
					DbUtil.close(conn);
        }
	}

}
