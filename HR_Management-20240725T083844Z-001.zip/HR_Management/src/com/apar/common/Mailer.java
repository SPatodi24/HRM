/**
 * ---------NOT USED----------
 *  A java class that contains send method to send the emails to the mentioned recipient.
 */

package com.apar.common;

import java.util.Properties;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Mailer {

	public static void send(String to) {

		final String from = "sakshi.misc22@gmail.com";
		final String pass = "testing123";
		
		Properties properties = System.getProperties();

		// Setup mail server
		properties.setProperty("mail.smtp.host", "smtp.gmail.com");

		System.out.println("setting up mail server");
		
		// Get the default Session object.
		Session session = Session.getDefaultInstance(properties);

		// 2)compose message
		try {
			// Create a default MimeMessage object.
			MimeMessage message = new MimeMessage(session);

			// Set From: header field of the header.
			message.setFrom(new InternetAddress(from));

			// Set To: header field of the header.
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

			// Set Subject: header field
			message.setSubject("This is the Subject Line!:reset password");

			// Now set the actual message
			message.setText("This is actual message: default password is 12345.");
				
			System.out.println("message created");
			
			// Send message
			Transport.send(message);
			System.out.println("Sent message successfully....");
		} catch (MessagingException mex) {
//			mex.printStackTrace();
			System.out.println("error from Mailer.java::"+mex.getMessage());
		}

		

	}
}
