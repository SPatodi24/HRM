/*
 * Java class to establish connection with database 
 */

package com.apar.dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionProvider {
//	static reference to itself
	private static ConnectionProvider instance = new ConnectionProvider();
	public static final String driver = "com.mysql.jdbc.Driver";
	public static final String url = "jdbc:mysql://localhost:3306/hrm_management";
	public static final String user = "root";
	public static final String password = "root";

	//private constructor
    private ConnectionProvider() {
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
        	System.out.println("class not found:connectionProvider"+e);
        	e.printStackTrace();
            
        }
    }
	
    private Connection createConnection() {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(url, user, password);
//            System.out.println("connection done:connectionProvider class");
        } catch (SQLException e) {
            System.out.println("ERROR: Unable to Connect to Database.");
        }
        return connection;
    }   
     
    public static Connection getConnection() {
        return instance.createConnection();
    }
}