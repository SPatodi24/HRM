package fetching_data;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequest;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FetchingEmployeeData {
	static final String DRIVER="com.mysql.jdbc.Driver";
	static final String DB_URL="jdbc:mysql://localhost:3306/hrm_management";		

	static final String USER="root";
	static final String PASS="root";
	static String l_query;
	String l_parameter;
	
	
//method to fetch parameters from jsp page	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		response.setContentType("text/html");
		try
		{
			l_query=request.getParameter("query");
			l_parameter=request.getParameter("parameter");
		}
		
		catch(Exception e)
		{  		pw.println(e.getMessage());   		}
	}
	
//method to display the result of the query	using maps
	public List getUserInfoByAlll() {
		return null;
				} 
//method to setup the connection to mysql
	public static void connection_setup()
	{
		Connection conn=null;
		Statement stmt=null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
		conn=DriverManager.getConnection(DB_URL,USER,PASS);
		
		System.out.println("query result");
		PreparedStatement ps=conn.prepareStatement("select * from emp_leave_details");
		ResultSet rs=ps.executeQuery();
		ResultSetMetaData rsmd=rs.getMetaData();  
		int total=rsmd.getColumnCount();
//		stmt=conn.createStatement();
//		String sql="select * from emp_leave_details";
//		ResultSet rs= stmt.executeQuery(sql);
		
		
		int count=0;
		while(rs.next())
		{  count++;
			String l_id=rs.getString("id_leaves");
			String eid=rs.getString("emp_id");
			int allowed=rs.getInt("allowed");
			int taken=rs.getInt("taken");
			int remain=rs.getInt("remaining");
			
		System.out.println(l_id + " "+eid+ "  "+ allowed+" "+taken+" "+remain);
		}
		System.out.println("number of rows="+count);
		rs.close();
		stmt.close();
		conn.close();
		
		
		}
		catch( Exception e)
		{
			System.out.println(e);
		}
		

	}
	
	public static void main(String[] args) {
		
		connection_setup();		
		
	}

}
