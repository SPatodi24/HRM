package fetching_data;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet_fetching_data
 */
@WebServlet("/Servlet_fetching_data")
public class Servlet_fetching_data extends HttpServlet {
	private static final long serialVersionUID = 1L;
	// Connection con=null;
	Connection con;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Servlet_fetching_data() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		response.setContentType("text/html");

		 String l_query=request.getParameter("query");
		 String l_parameter=request.getParameter("parameter");

		PrintWriter out = response.getWriter();

		try {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hrm_management", "root", "root");
				out.print("connection done");
				out.print("<br/>");
			} catch (Exception e) {
				out.print(e + " : error in connection");
				out.print("<br/>");
			}
//			PreparedStatement ps = con.prepareStatement("select * from emp_leave_details");
			PreparedStatement ps = con.prepareStatement(l_query);
			ResultSet rs = ps.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int total_col = rsmd.getColumnCount();
			// ---------------------------------------------------------------all good

			// putting result in map

			List<Map<String, String>> list = new ArrayList<Map<String, String>>();
			ResultSetMetaData meta = rs.getMetaData();
			
			while (rs.next()) {
				Map map = new HashMap();							//will come inside loop only
				for (int i = 1; i <= meta.getColumnCount(); i++) {
					String key = meta.getColumnName(i);
					// out.println("key="+key);
					String value = rs.getString(key);
					// out.println("value=" +value);
					map.put(key, value);
				}
				list.add(map);
				
			}
			
// printing result
			/*out.print("<table width=50%>");
			out.print("<caption>Result:</caption>");
		*/
			
			for (int i =0; i < list.size(); i++) {

				out.println(list.get(i));
				out.println("<br><br>");
//				out.println("<tr>" + list.get(i) + "</tr>");
			}

//			out.print("</table>");

		} catch (Exception e2) {
			e2.printStackTrace();
		}

		finally {
			out.close();
		}

	}
}
